import boto3
import json
from boto3.dynamodb.conditions import Key, Attr
import pandas as pd

def lambda_handler(event, context):
    
    try:
        #1. Read Task configuration
        dynamodb = boto3.resource('dynamodb')
        table =dynamodb.Table('ECSTaskConfig')
        response = table.scan()
        data = response['Items']
        while 'LastEvaluatedKey' in response:
            response = table.query(ExclusiveStartKey=response['LastEvaluatedKey'])
            data.update(response['Items'])
        df = pd.DataFrame(data)

        #2. check if task configured in dynamodb
        if len(df[df["TaskID"] == event["TaskID"]]) >0 : 
            df = df[df["TaskID"] == event["TaskID"]]
        else:
            raise Exception("Unable to read task configuration from dynamodb... task been condifured in dynamodb in ECSTaskConfig table")

        #TODO 3. check if this task depend on another task... if true check the other task finished and sucessful 
        
        #4. Map the Container type from dynamodb with ECS 
        CurrentTaskDefinition = 'None'
        
        
        if df["TargetPhase"][0] == 'smEngine':
            CurrentTaskDefinition = 'smEngine:3'
        elif df["TargetPhase"][0] == 'midEngine':
            CurrentTaskDefinition = 'midEngine:1'
        elif df["TargetPhase"][0] == 'largeEngine':
            CurrentTaskDefinition = 'largeEngine:1'
        elif df["TargetPhase"][0] == 'smGPUEngine':
            CurrentTaskDefinition = 'smGPUEngine:1'
        elif df["TargetPhase"][0] == 'midGPUEngine':
            CurrentTaskDefinition = 'midGPUEngine:1'
        
        ECSContainerName = df["ECSContainerName"][0]
        
        environment= {
            'MainFileName': df["MainFileName"][0],
            'SourceBucket': df["Bucket"][0],
            'ProjectName': df["ProjectName"][0],
            'S3Key':df["S3Key"][0]
        }
        environment = json.dumps(environment, default=str)
        
        #5. Intiate your container via getting the configs from df from dynamodb 
        client = boto3.client("ecs", region_name="us-east-1")
        if CurrentTaskDefinition != 'None':
            response = client.run_task(
            taskDefinition=CurrentTaskDefinition,
            launchType=df["LaunchType"][0],
            cluster=df["Cluster"][0],
            group='InvokedByPostELT',
            platformVersion='LATEST',
            count=1,
            networkConfiguration={
                'awsvpcConfiguration': {
                    'subnets': [
                        'subnet-071cfba5a0cacf3eb',
                    ],
                    'assignPublicIp': 'ENABLED',
                    'securityGroups': ["sg-0e0dac418fb9f9264"]
                    }
                },      
                overrides={
                    'containerOverrides': [
                        {
                            'name': ECSContainerName, 
                            'environment': [
                                {
                                    'name': 'MainFileName',
                                    'value': df["MainFileName"][0]
                                },
                                {
                                    'name': 'SourceBucket',
                                    'value': df["Bucket"][0]
                                },
                                {
                                    'name': 'ProjectName',
                                    'value': df["ProjectName"][0]
                                },                               
                                {
                                    'name': 'S3Key',
                                    'value': df["S3Key"][0]
                                }
                            ],
                        }
                    ]
                }
            )        
            print('meow i r here')
            #print(json.dumps(response, indent=4, default=str))
            failures = response['failures']
            HTTPStatusCode = response['ResponseMetadata']['HTTPStatusCode']        
            ContainerList = response['tasks'][0]['containers']
            ContainerARN = ContainerList[0]['containerArn']
            TaskARN = ContainerList[0]['taskArn']
            ImageUsed = ContainerList[0]['image']
            CPUReserved = ContainerList[0]['cpu']
            MemoryReserved = ''
            #MemoryReserved = ContainerList[0]['memoryReservation']
            
            print('CurrentTaskDefinition='+CurrentTaskDefinition)
            print('ContainerARN='+ContainerARN)
            print('TaskARN='+TaskARN)
            print('ImageUsed='+ImageUsed)
            print('CPUReserved='+CPUReserved)
            #print('MemoryReserved='+MemoryReserved)
        else:
            print('Undefined operation. Received '+event['TargetPhase'])
            raise Exception('Undefined operation. Received '+event['TargetPhase'])
                    
        return {
            'statusCode': HTTPStatusCode,
            'CurrentTaskDefinition': CurrentTaskDefinition,
            'ContainerARN': ContainerARN,
            'TaskARN' : TaskARN,
            'ImageUsed' : ImageUsed,
            'CPUReserved' : CPUReserved,
            'MemoryReserved' : MemoryReserved,
            'message': ''
        }
    except Exception as e:
        return {
            'statusCode': '500',
            'message': str(e)
        }